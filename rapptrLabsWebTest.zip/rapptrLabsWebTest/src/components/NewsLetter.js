import React, { Component } from 'react';
import '../assets/css/newsletter.min.css';
import axios from 'axios';

export class NewsLetter extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
             email: ''
        }
    }
    
    handleChange = (event) => {
        this.setState({[event.target.name]: event.target.value});
    }
        
    handleSubmit = (event) =>{
        event.preventDefault()
        let url = "http://dev.rapptrlabs.com/Tests/scripts/add-email.php";
        let formData = new FormData();
        formData.append('email', this.state.email);

    
        axios.post(url, formData
            ).then((response) => {
                let data = response.data;
                if (data.code == "Success"){
                    alert(`Successfully Subscribed`);
                } else{
                    alert('Error in subscribing email');
                }
            }).catch((error) => {
                alert("Something went wrong"); 
        
            }).finally(()=> {
                this.setState({
                    email: '',
                })
            });
        

        
    }

    render() {
        return (
            <div className='newsletter'>
                
                <h2>Subscribe to our NewsLetter</h2>
                <form class="form-inline" onSubmit={this.handleSubmit} autoComplete="off">

                    <input type="email" id="email" value={this.state.email} placeholder="Enter email" name="email" onChange={this.handleChange}/>
                    <button type="submit">Subscribe</button>
                </form>
            

            </div>
        )
    }
}

export default NewsLetter

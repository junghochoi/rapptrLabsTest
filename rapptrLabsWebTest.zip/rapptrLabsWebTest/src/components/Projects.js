import React from 'react'
import Applciation, { Application } from '../components/Application'
import '../assets/css/projects.min.css'
import MovoLogo from '../assets/imgs/logo_movo@2x.png'
import TappingSolutionLogo from '../assets/imgs/logo_tappingSolution@2x.png'
import Conair from '../assets/imgs/logo_conair@2x.png'
import goTenna from '../assets/imgs/logo_goTenna@2x.png'


function Projects() {


    let movoLink = 'https:movo.me';
    let conairLink = 'https://apps.apple.com/us/app/ww-body-analysis-scale-tracker/id1157071126?mt=';
    let tappingSolutionLink = 'https://itunes.apple.com/us/app/the-tapping-solution/id1419815487?mt=8';
    let goTennaLink = 'https://www.gotenna.com'


    return (
        <div className='projects'>
            <h2>Our Apps</h2>

            <div className='apps'>
                <Application app={MovoLogo} appTitle="Movo" appLink={movoLink} />
                <Application app={Conair} appTitle="Conair WeightWatchers" appLink={conairLink}/>
                <Application app={TappingSolutionLogo} appTitle="TappingSolution" appLink={tappingSolutionLink}/>
                <Application app={goTenna} appTitle="goTenna" appLink={goTennaLink} />
  
            </div>
        </div>
    )
}

export default Projects

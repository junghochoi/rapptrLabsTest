import React from 'react';
import '../assets/css/footer.min.css';

function Footer() {
    return (
        <div className='footer'>
            Footer
        </div>
    )
}

export default Footer

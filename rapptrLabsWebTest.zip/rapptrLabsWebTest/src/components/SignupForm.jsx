


import React, { Component } from 'react'
import {Link} from 'react-router-dom';
import emailIcon from '../assets/imgs/ic_email@2x.png'
import passwordIcon from '../assets/imgs/ic_password@2x.png'
import usernameIcon from '../assets/imgs/ic_username@2x.png'
import axios from 'axios'

export class SignupForm extends Component {
    constructor(props){
        super(props)
    
        this.state = {
            username: '',
            password: '',
            email: ''
        }
    }
    

    handleChange = (event) => {
        this.setState({[event.target.name]: event.target.value});
    }

    
    handleSubmit = (event) =>{
        event.preventDefault()

        

        let url = "http://dev.rapptrlabs.com/Tests/scripts/user-signup.php"
        let formData = new FormData();
        formData.append('email', this.state.email);
        formData.append('password', this.state.password);
        formData.append('username', this.state.username);

        axios.post(url, formData
            ).then((response) => {
                let data = response.data;
                alert(`Successfully Signed Up:\n${data.user_username}\n${data.user_email}`);
 
        

            }).catch((error) => {
                console.log(error);
            }).finally(() =>{
                
                this.setState({
                    email: '',
                    password: '',
                    username: ''
                })
            });
        

        
    }

    render (){ 
        const used = {
            textDecoration: 'underline'
          };
    
        const unused ={
            color: 'rgba(255,255,255,0.3)'
        }
        return (
            
            <>
            <div className="credentials-form-headers">
                <Link to='/login' style={unused}><h3>Login</h3></Link>
                <Link to='/signup' style={used}><h3>Signup</h3></Link>
            </div>

            <form onSubmit={this.handleSubmit} className="input-fields" autoComplete="off">
                <div className='input-container'>
                    <img src={usernameIcon}/>
                    <input type='text' placeholder="Username" value ={this.state.username} name="username" onChange={this.handleChange}/>
                </div>
                <div className='input-container'>
                    <img src={emailIcon}/>
                    <input type='text' placeholder="Email" value={this.state.email} name="email" onChange={this.handleChange}/>
                </div>
                <div className='input-container'>
                    <img src={passwordIcon}/>
                    <input type='password' placeholder="Password" value = {this.state.password} name="password" onChange={this.handleChange}/>
                </div>
                <div className='input-container'>
                    <button>Signup</button>
                </div>

            </form>
            </>
    
        )
    }

}

export default SignupForm


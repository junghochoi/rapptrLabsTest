import React from 'react'
import Showcase from '../components/Showcase';
import About from '../components/About'; 
import Projects from '../components/Projects';
import Footer from '../components/Footer'
import NewsLetter from '../components/NewsLetter';
import '../assets/css/default.min.css'

function Home() {

    return ( 
        <div className = "App" >
          <Showcase />
          <About />
          <Projects />
          <NewsLetter />
          <Footer />
        </div>
      );
}

export default Home

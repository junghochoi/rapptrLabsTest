import React from 'react'
import '../assets/css/about.min.css'

function About() {
    return ( 
        <div className = 'about' >
            <h2 className = 'title'> Who we are </h2>

            <div className = 'introduction' >
                <p>  Rapptr Labs is a Jersey City - based app development firm that works with Fortune 500 brands, leading retailers, funded startups and more to craft digital products and strategies that solve business problems and drive measurable results </p> 
                <p> We're part of your team. That means working together to meet the business challenges you face. From iOS and Android to emerging technologies like VR, AR, and wearables, we do whatever it takes to help you thrive in today's - and tomorrow 's - digital ecosystem.</p>
            </div> 
        
        </div >
    )
}

export default About
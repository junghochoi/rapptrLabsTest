import React, { Component } from 'react'

export class Application extends Component {
    render() {
        return (
            <div className="app">
                <a href={this.props.appLink}>
                    <img src={this.props.app}/>
                </a>
                
                <h5>{this.props.appTitle}</h5>
            </div>
        )
    }
}

export default Application

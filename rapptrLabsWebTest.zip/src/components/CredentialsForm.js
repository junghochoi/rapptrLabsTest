import React from 'react';


import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";


import LoginForm from './LoginForm';
import SignupForm from './SignupForm';


function CredentialsForm() {



    return (
        <>
        <div className="credentials-form">
 
            <Router>
                <Switch>
                    <Route component={LoginForm} path='/login'/>
                    <Route component={SignupForm} path='/signup'/>
                </Switch>
            </Router>
        </div>
        </>
    )
}

export default CredentialsForm

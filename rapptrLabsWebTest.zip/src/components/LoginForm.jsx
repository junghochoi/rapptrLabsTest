import React, {Component} from 'react'
import {Link} from 'react-router-dom';
import emailIcon from '../assets/imgs/ic_email@2x.png'
import passwordIcon from '../assets/imgs/ic_password@2x.png'
import axios from 'axios';

export class LoginForm extends Component {

    constructor(props){
        super(props)
    
        this.state = {

            password: '',
            email: ''
        }
    }
    

    handleChange = (event) => {
        this.setState({[event.target.name]: event.target.value});
    }

    
    handleSubmit = (event) =>{
        event.preventDefault()

        let url = "http://dev.rapptrlabs.com/Tests/scripts/user-login.php"
        let formData = new FormData();

        formData.append('email', this.state.email);
        formData.append('password', this.state.password);
        
        axios.post(url, formData
            ).then((response) => {
                let data = response.data;
                alert(`Successfully Logged in:\n${data.user_username}\n${data.user_email}`);
            }).catch((error) => {
                alert("Unauthorized Error: Incorrect Username or Password"); 
        
            }).finally(()=> {
                this.setState({
                    email: '',
                    password: ''
                })
            });        
    }


    render() {

        const used = {
            textDecoration: 'underline'
          };
    
        const unused ={
            color: 'rgba(255,255,255,0.3)'
        }
        return (
            <>
                <div className="credentials-form-headers">

                    <Link to='/login' style={used}><h3>Login</h3></Link>
                    <Link to='/signup' style={unused}><h3>Signup</h3></Link>
                </div>

                <form onSubmit={this.handleSubmit} className="input-fields"  autoComplete="off">

                    <div className="input-container">
                        <img src={emailIcon}/>
                        <input type='text' placeholder="Email" value={this.state.email} name="email" onChange={this.handleChange}/>
                    </div>
                    
                    <div className="input-container">
                        <img src={passwordIcon}/>
                        <input type='password' placeholder="Password" value={this.state.password} name="password" onChange={this.handleChange}/>
                    </div>

                    <div className="input-container">
                        <button>Login</button>
                    </div>

                </form>
            </>
        )   
    }
}

export default LoginForm




import React, { Component } from 'react';
import '../assets/css/showcase.min.css'
import logoURL from '../assets/imgs/gpc_logo_large@2x.png';

import {Link} from 'react-router-dom';


export class Showcase extends Component {
    render() {
        return (
            <div className='showcase'>

                <div className='login'>
                    <Link to='/login'>Login</Link>
            
                </div>
                <div className='main'>
                    <img src={logoURL}/>
                    <h2>API Design & Development Agency</h2>
                </div>
                
                
            </div>
        )
    }
}

export default Showcase

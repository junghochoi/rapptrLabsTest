import React from 'react';
import {Link} from 'react-router-dom';
import '../assets/css/credentials.min.css';

import CredentialsForm from '../components/CredentialsForm';
import Logo from '../assets/imgs/gpc_logo@2x.png';

function Credentials() {
    return (
        <div className='credentials-page'>

            <Link to="/"className="form-logo" >
                <img src={Logo} />
            </Link>
            <CredentialsForm />
        </div>
    )
}

export default Credentials

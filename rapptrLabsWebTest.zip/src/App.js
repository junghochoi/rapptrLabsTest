import React from 'react';


import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";



import HomePage from './pages/Home'
import Credentials from './pages/Credentials'


function App() {

  return (
    <Router>

      <Switch>
        <Route component={HomePage} exact path="/"/>
        <Route component={Credentials} path="/login" />
        <Route component={Credentials} path="/signup" />
      

      </Switch>
  

    </Router>
    

  )
}

export default App;